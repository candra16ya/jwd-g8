<!DOCTYPE html>
<html>

<body>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        Jumlah Bintang: <input type="number" name="star_size">
        <br>
        <input type="submit" value="Submit">
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // collect value of input field
        $name = $_POST['star_size'];
        //Melakukan pengecekan form kosong
        if (!empty($name)) {
            //Melakukan inputan bintang sesuai inputan yang dimasukkan
            for ($i = 0; $i <= $name; $i++) {
                //Membentuk sebuah bintang sesuai inputan yang di masukkan
                for ($j = 1; $j <= $i; $j++) {
                    echo "* ";
                }
                echo "<br>";
            }
            //Menampilkan popup ketika form kosong
        } else {
            echo "<script>alert('FORM TIDAK BOLEH KOSONG')</script>";
        }
    }
    ?>

</body>

</html>